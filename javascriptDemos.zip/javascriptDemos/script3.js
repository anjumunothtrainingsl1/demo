var arr=["running","singing","dancing","coding"];
var result=arr.map((item)=>{
    return item.slice(1,4);
});

console.log(result);//["unn","ing","anc","odi"]

var projectArr=[
{projectId:"P101",projectName:"Store Front",projectDescription:"E Commerce Application"},
{projectId:"P102",projectName:"CueBack",projectDescription:"Social Networking"},
{projectId:"P103",projectName:"Premium Access",projectDescription:"Digital Course Library"},
{projectId:"P104",projectName:"Freegal Music",projectDescription:"Libary of Songs"},
{projectId:"P105",projectName:"Comlink Data",projectDescription:"Data Science"}];


var result=projectArr.map(item=>{
    return item.projectDescription;
})

console.log(result);//["E Commerce Application","Social Networking","Digital Course Library","Libary of Songs","Data Science"]
