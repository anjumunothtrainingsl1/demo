function loginEventHandler()
{
    var errorMessageElement=document.getElementById("errorMessage");
    errorMessageElement.innerHTML="";
    var userNameElement=document.getElementById("txtUserName");
    var passwordElement=document.getElementById("txtPassword");
    var userName=userNameElement.value;
    var password=passwordElement.value;
    if(userName =="")
    {
        errorMessageElement.innerHTML="UserName cannot be empty";
       
    }
    if(password =="")
    {
        errorMessageElement.innerHTML+="<br />Password cannot be empty";
       
    }
    // password is having atleast one uppercase char and one lowercase char
        //uppercase char
    var upperCaseFlag=false;
    for(var i=0;i<password.length;i++)
    {
        if((password.charAt(i)>="A") && (password.charAt(i)<="Z"))
        {
            upperCaseFlag=true;
            break;
            
        }
    }
    if(upperCaseFlag == false)
    {   
        errorMessageElement.innerHTML+="<br />Min one upper case char needed in the password";
    }
    var lowerCaseFlag=false;
    for(var i=0;i<password.length;i++)
    {
        if((password.charAt(i)>="a") && (password.charAt(i)<="z"))
        {
            lowerCaseFlag=true;
            break;
            
        }
    }
    if(lowerCaseFlag == false)
    {   
        errorMessageElement.innerHTML+="<br />Min one lower case char needed in the password";
    }

    //regular expressions 

}