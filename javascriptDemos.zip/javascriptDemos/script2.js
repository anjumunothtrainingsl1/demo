/*
various datatypes

*/

var myDate=new Date(2020,4,4,4,4);// 4 may 2020 4hours 4 min ;
var myDate=new Date(2020,4,34,4,4);// 3 june 2020 4hours 4 min ;

// date getter functions

myDate.getDate();//3
myDate.getDay();// 3
myDate.getFullYear();//2020

//setter functions

myDate.setHours(18);// 6pm
myDate.setDate(23);// 23 june 2020;


// Functions in js

function myFunc(p1,p2)
{
    console.log("p1 +p2 ="+(p1+p2));
}

myFunc(10,20);//30

myFunc(20,12.5);//32.5
myFunc(1,"hello");//"1hello"
myFunc("1",3);//"13"
myFunc("hello","people");//"hellopeople"
myFunc(1,true);//2;

myFunc();//NaN
myFunc(1);//NaN
myFunc(1,2);//3
myFunc(1,2,3);//3
myFunc(1,2,3,4,5,6);//3

var mySum1=1+"2"+2;//"122"
mySum2=1+2+"2";//"32"
mySum2="1"+2+"2";//"122"
mySum2="1"+"2"+"2";//"122"
mySum1=1+"2"+2+2;//"1222"

var arr=[10,20,30,40,50];
arr.splice(2,2,33,44);//
arr.splice(2,1);

function myFunc2(p1,p2)
{
    if(p1==undefined)
    {
        p1=0;
    }
    if(!p2)
        p2=0;
    console.log(p1+p2);
}
myFunc2();//0
myFunc2(1);//1
myFunc2(1,2);//3
myFunc2(1,2,3);//3
myFunc2(1,2,3,4,5,6);//3

function myFunc3(p1,p2)
{
    var sum1=0;
    for(var i=0;i<myFunc3.arguments.length;i++)
    {
        sum1+=myFunc3.arguments[i];
    }
    console.log(sum1);
}
myFunc3();//0
myFunc3(1);//1
myFunc3(1,2);//3
myFunc3(1,2,3);//6
myFunc3(1,2,3,4,5,6);//21

//es6 rest parameter

function myFunc4(...p1)
{
    var sum1=0;
    for(var i=0;i<p1.length;i++)
    {
        sum1+=p1[i];
    }
    console.log(sum1);
}
myFunc4();//0
myFunc4(1);//1
myFunc4(1,2);//3
myFunc4(1,2,3);//6
myFunc4(1,2,3,4,5,6);//21

// IIFE Immediately invoked function expression

function myFunc5(str,pos)
{
    var str1=str.charAt(pos);//"d"
    console.log("The character at position "+pos +" in "+ str + " is : "+str1);
}

myFunc5("good morning",3);

(function myFunc5(str,pos)
{
    var str1=str.charAt(pos);//"d"
    console.log("The character at position "+pos +" in "+ str + " is : "+str1);
})("beautiful",3);//u


//Anonymous function

function myFunc6(str, subStr)
{
    var pos=str.indexOf(subStr);
    console.log("The index of the substring "+subStr+" in str "+str+ "is "+pos  );
}

myFunc6("happy morning","a");//1
myFunc6("happy morning","z");//-1
myFunc6("happy morning","p");//2
myFunc6("happy morning","P");//-1

"happy morning".indexOf("p",3);//3
"happy morning".indexOf("n",10);//11
//function literal
var f1=function(str, subStr)
{
    var pos=str.indexOf(subStr);
    console.log("The index of the substring "+subStr+" in str "+str+ "is "+pos  );
    return pos;
}
var result=f1("friendship","d");
console.log(result);//5

//use cases 2
//1. in an object
var empObj={
    empId:101,
    empName:"Sara",
    salary:5678,
    printDetails:function ()
    {
        console.log("Emp id"+ this.empId);
        console.log("Emp Name"+ this.empName);
        console.log("Salary"+ this.salary);
        
    }
};
empObj.printDetails();

// use case 

function myFunc7(p1)
{
    p1();//"Its time for the break"
    //myFunc8();//error
}

myFunc7(function (){console.log("Its time for the break")});

//dt number. string,boolean.array,object,date,function

var arr=[10,20,30];
//es6 array functions
var resArr=arr.map(
    function(item)
    {
     return item*item;
    }
);//[100,400,900]
arr=[10,20,30];
resArr=arr.map(
    function(item)
    {
        if(item >15)
            return item*item;
    }
);
console.log(resArr);//[ud,400,900]


var days=["monday","tuesday","wednesday","thursday","friday","saturday","sunday"];
var outputArr=days.map(function(item){
    return item.slice(0,3).toUpperCase();
})

console.log(outputArr);//["MON","TUE","WED","THU","FRI","SAT","SUN"]

"good morning".slice(0,3);//substring start=0;end= 3; goo

//

arr=[10,99,26,55,73];
arr.sort();
console.log(arr);//[10,26,55,73,99];

arr=[112,23,203,45,99];
arr.sort();
console.log(arr);//[112,203,23,45,99]

arr.sort(function(a,b){
    if(a>b)
        return 1;
    else
        if(a<b)
            return -1
        else
            return 0;
})
console.log(arr);//[23,45,99,112,203]

//json
var empArr=[
    {"empId":101,"empName":"Sara","salary":7687},
    {empId:102,empName:"Tara",salary:687},
    {empId:103,empName:"Lara",salary:768},
    {empId:104,empName:"Kishan",salary:7687}
];

var empIdArr=empArr.map(function (item){
        return item.empId;
}
);

console.log(empIdArr);//[101,102,103,104]
empArr=[
    {"empId":101,"empName":"Sara","salary":7687},
    {empId:102,empName:"Tara",salary:687},
    {empId:103,empName:"Lara",salary:768},
    {empId:104,empName:"Kishan",salary:7687}
];
empArr.sort(function(emp1,emp2){
    if(emp1.salary>emp2.salary)
        return 1
    else
        if(emp1.salary<emp2.salary)
            return -1
        else
            return 0;
})

console.log(empArr);
/*
[{empId:102,empName:"Tara",salary:687},
 {empId:103,empName:"Lara",salary:768},
 {"empId":101,"empName":"Sara","salary":7687},
 {empId:104,empName:"Kishan",salary:7687}
];

*/

var result=empArr.find(function (item){
    if(item.salary ==7687)
        return true;
});
console.log(result);//{"empId":101,"empName":"Sara","salary":7687}

var result=empArr.filter(function (item){
    if(item.salary ==7687)
        return true;
});
console.log(result);//[{"empId":101,"empName":"Sara","salary":7687},{empId:104,empName:"Kishan",salary:7687}]

var result=empArr.find(function (item){
    if(item.salary ==1234)
        return true;
});
console.log(result);//ud

var result=empArr.filter(function (item){
    if(item.salary ==1234)
        return true;
});
console.log(result);//[]

//findIndex
var result=empArr.findIndex(function (item){
    if(item.salary ==1234)
        return true;
});
console.log(result);//-1

var result=empArr.findIndex(function (item){
    if(item.salary ==7687)
        return true;
});
console.log(result);//2


//filterIndex
/* var result=empArr.filterIndex(function (item){
    if(item.salary ==7687)
        return true;
});
console.log(result);//error
 */

 // arrow function

var f2= function (p1,p2)
 {
     console.log(p1+p2);
 }
 f2=(p1,p2) => {console.log(p1+p2)};
 f2=p1=>{console.log(p1)}
 f2=()=>{console.log("hello")};
 f2=(p1,p2)=>p1+p2;

 arr=[10,20,30];
 arr.map(item=>item*item);
 var empName="james";
 var obj={
     empId:101,empName:"sara",salary:5678,
     printDetails:function(){
         console.log(this.empId);//101
         console.log(this.empName);//sara
         console.log(empName);//james

     },
     displayName:()=>{
         //lexical scope
         console.log(this.empName);//james
     }
 }
 obj.printDetails();
 obj.displayName();





