alert("Welcome to javascript");

//declarartion and data types
// var
//es6 --> let const

//weakly typed language

var i;// value :undefined ; datatype : undefined
i=10;// value:10; dt: number
i=10.5678;//10.5678; number

// type inference 
i="hello";//"hello" ; string
i='a';//'a'; string

i=true;//true; boolean
i=false;

// int i; i=10; i=23.5;

// array
i=[10,20,30];
console.log("Elements in the array",i);
console.log("Number of elements in the array: "+i.length );

i=[10,"hello",66.67,"morning",true,1];
console.log("New elements",i);

console.log("Element at 3rd position: "+i[3]);//"morning"

i[2]=99;
console.log("New elements",i);//[10,"hello".99,"morning",true,1];
i[5]="people";//[10,"hello".99,"morning",true,people]

console.log("New elements",i);
i[100]="sorry";// 101 elements
console.log("New elements",i);


var alphabets=["a","b","c","d"];
alphabets.push("e");
console.log("Alphabets array",alphabets);

var result=alphabets.pop();//"e"
console.log("Popped out element : "+result);//"e"
alphabets.shift();//remove "a"
alphabets.unshift("A");//add "A"
console.log(alphabets)

alphabets.splice(3,0,"D");
alphabets.splice(1,0,"B");
console.log(alphabets);
var alphabets=["a","b","c","d","e","f"];
alphabets.splice(2,2);//["a","b","e","f"];

console.log(alphabets);

var alphabets=["a","b","c","d","e","f"];
alphabets.splice(3,2,"G","H");// ["a","b","c","G","H","f"]

var alphabets=["a","b","c","d","e","f"];
alphabets.splice(1,3,"G","H");//[a,G,H,e,f]

var alphabets=["a","b","c","d","e","f"];
alphabets.splice(5,0,"G","H");//[a,b,c,d,e,G,H,f];

// object
//property, fields,keys --
//key:value pair 
var obj={
    empId:101,
    empName:"sara",
    salary:1234
}
console.log("Employee id : "+ obj.empId);
console.log("Employee details",obj);

obj.empId=999;
obj.salary = 6789;
delete obj.empName;

obj.deptId="D1";//add a new field to obj
console.log("Employee details after updation",obj);


obj["empId"]=777;
// copy and reference
var i=10;
var j=20;
j=i;
i=100;
console.log("i= "+i);//100
console.log("j= "+j);//10

//non primitive dt array,object

var arr=[10,20,30];
var arr1=arr;// reference 
arr1[0]=999;
console.log(arr);//[999,20,30]
console.log(arr1);//[999,20,30]

var obj={
    empId:101,
    empName:"sara",
    salary:1234
};
var obj1=obj;
obj1.empId=999;
console.log("obj:",obj);//{999,"sara",1234}
console.log("obj1:",obj1);//{999,"sara",1234}

// date

var today=new Date();// current date and time along with the day
console.log(today);

var myDate=new Date(1000);
console.log(myDate);//1000 ms after 1st jan 1970 (epoch date)12:00am 1sec

var myDate=new Date("1/1/2020");
myDate=new Date("3/4/2002");//
console.log(myDate);

var sanjayBDay=new Date(2000,1,1);
console.log(sanjayBDay);
var anyDay=new Date(2000,4,26,5,32,54,23);//26th may 2000 5:32:54:23
console.log(anyDay);
































